var sparkle;
var reverb;
var capture;

function preload(){
  sparkle = loadSound("sparkle.wav");  //loads the sound file
}

function setup() {
  createCanvas(400, 400);
  
  reverb = new p5.Reverb();            //adds reverb effect
  reverb.process(sparkle,5,60);
  sparkle.play()                       //plays sound on run
  
  capture = createCapture(VIDEO);     //captures webcam video
  capture.size(240,240);    
  capture.hide();
}

function draw() {
  background(80);
  ellipse(200,200,300,400);           //draws "mirror"
  imageMode(CENTER);
  image(capture,200,200,240,240);     //places live video
  filter(THRESHOLD);                  //adds filter
}