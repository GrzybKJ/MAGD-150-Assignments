function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(50);
  
  push();  //calls for the first block to be translated
  tetris1();
  translate(100,0);
  tetris1();
  translate(100,0);
  tetris1();
  translate(100,0);
  tetris1();
  pop();
  
  push();  //calls for the second block to be scaled down
  tetris2();
  scale(0.5);
  translate(300,200);
  tetris2();
  pop();
  
  push();  //I couldn't get the rotate function to work
  tetris3();
  rotate(HALF_PI);
  tetris3();
  pop();
}

function tetris1(){  //constructs the first block
  fill('#FC20FF');
  stroke('#AA13E8');
  strokeWeight(5);
  rect(5,20,30,30);
  rect(35,20,30,30);
  rect(65,20,30,30);
  rect(35,50,30,30);
}

function tetris2(){  //constructs the second block
  fill('#28D9FF');
  stroke('#1A8CE8');
  strokeWeight(5);
  rect(120,140,30,30);
  rect(150,140,30,30);
  rect(120,170,30,30);
  rect(150,170,30,30);
}

function tetris3(){  //constructs the thrid block
  fill('#00FF2A');
  stroke('#2BE80C');
  strokeWeight(5);
  rect(120,240,30,30);
  rect(120,270,30,30);
  rect(150,270,30,30);
  rect(150,300,30,30);
}