var p = 0;

function setup() {
  createCanvas(400, 400);
  background(220);
}

function draw() {
  noStroke();
  fill('#FFEFAA');
  ellipse(200,200,350,350);
  fill('#E81738');
  ellipse(200,200,310,310);
  fill('#FEFF52');
  ellipse(200,200,290,290);
  
  textFont('trebuchet ms');
  textSize(60);
  fill(t1,t2,t3);
  stroke(t1,t2,t3);
  text('PIZZA TIME!',45,50); 
  
  if(p<50){
    fill('#FF221B');
    noStroke();
    ellipse(200,200,p,p);
    ellipse(140,130,p,p);
    ellipse(220,100,p,p);
    ellipse(270,170,p,p);
    ellipse(110,230,p,p);
    ellipse(150,300,p,p);
    ellipse(290,250,p,p);
    ellipse(230,290,p,p);
    p++
  }
  if(p==50){
  fill('#FF221B');
  noStroke();
  ellipse(200,200,p,p);
  ellipse(140,130,p,p);
  ellipse(220,100,p,p);
  ellipse(270,170,p,p);
  ellipse(110,230,p,p);
  ellipse(150,300,p,p);
  ellipse(290,250,p,p);
  ellipse(230,290,p,p);
  }
  
  for(let x=p;x<50;x++){
    textFont('trebuchet ms');
    textSize(20);
    fill(0);
    stroke(0);
    text('Loading...',150,350);
  }
}

var c1=0;
var c2=0;
var c3=0;

function keyPressed(){
  if(c1>=255){
    c1=0;
  }
  if(c2>=255){
    c2=0;
  }
  if(c3>=255){
    c3=0;
  }
  background((c1=random(0,255)),(c2=random(0,255)),(c3=random(0,255)));
}

var t1=0;
var t2=0;
var t3=0;

function mousePressed(){
  if(t1>=255){
    t1=0;
  }
  if(t2>=255){
    t2=0;
  }
  if(t3>=255){
    t3=0;
  }
  t1=random(0,255);
  t2=random(0,255);
  t3=random(0,255);
}