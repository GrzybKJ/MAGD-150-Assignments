function setup() {
  createCanvas(400, 400);
}

function draw() {
  colorMode(HSB,360,100,100,100);
  background(252,87,25);
  //stars
  
  //water
  noStroke();
  colorMode(RGB,255,255,255,100);
  fill(55,172,255);
  arc(400, 400, 400, 400, PI,PI+HALF_PI,PIE);
  //land
  beginShape();
  vertex(300,250);
  vertex(395,230);
  vertex(350,390);
  vertex(320,330);
  vertex(230,320);
  fill('#1F803D');
  endShape(CLOSE);
  beginShape();
  vertex(220,330);
  vertex(300,340);
  vertex(340,400);
  vertex(240,400);
  fill('#1F803D');
  endShape(CLOSE);
  beginShape();
  vertex(400,400);
  vertex(400,260);
  vertex(370,385);
  vertex(380,400);
  fill('#1F803D');
  endShape(CLOSE);
  //stars
  strokeWeight(5);
  stroke(255);
  point(30,30);
  point(300,80);
  point(200,10);
  point(100,130);
  point(50,250);
  point(120,330);
  point(210,230);
  //moon
  noStroke();
  fill(230);
  ellipse(280,140,60,60);
  //rocket
  fill('#E8130C');
  triangle(40,200,80,160,40,160);
  quad(140,230,100,270,100,300,170,230);
  fill('#C3E4FF');
  quad(40,200,80,160,140,230,100,270);
  fill(200);
  ellipse(80,200,30,30);
  //ringed planet
  fill('#E87B23');
  ellipse(140,60,30,10);
  fill('#FFA626');
  ellipse(140,60,15,15);
  //purple planet
  fill('#9D0AFF');
  ellipse(30,350,15,15);
  //red planet
  fill('#FF2800');
  ellipse(360,30,15,15);
  //aqua planet
  fill('#1EE0FF');
  ellipse(180,290,15,15);
  //lime planet
  fill('#0AFF00');
  ellipse(10,120,15,15);
}
