let garden = [];  //creates garden array

function setup() {
  createCanvas(600, 400);
  garden[0] = new flower(100,100);  //initializes and specifies
  garden[1] = new flower(400,150);  //locations of each flower
  garden[2] = new flower(250,20);   //in the garden
  garden[3] = new flower(200,250);
  garden[4] = new flower(50,350);
  garden[5] = new flower(550,100);
  garden[6] = new flower(350,400);
  garden[7] = new flower(525,300);
}

function draw() {
  background('#5CD631');
  garden[0].grow();    //draws each flower
  garden[1].grow();
  garden[2].grow();
  garden[3].grow();
  garden[4].grow();
  garden[5].grow();
  garden[6].grow();
  garden[7].grow();
}

class flower {
  constructor(x,y) {
    var fx,fy,cr,cg,cb,pr,pg,pb,pr2,pg2,pb2;
    
    this.fx = x    //gets center x coordinate
    this.fy = y    //gets center y coordinate
    this.cr = random(255);    //randomizes center color
    this.cg = random(255);
    this.cb = random(255);
    this.pr = random(255);    //randomizes first petal color
    this.pg = random(255);
    this.pb = random(255);
    this.pr2 = random(255);   //randomizes second petal color
    this.pg2 = random(255);
    this.pb2 = random(255);
  }
  
  grow(){
    fill(this.cr,this.cg,this.cb);
    ellipse(this.fx,this.fy,40,40);    //draws center
    
    fill(this.pr,this.pg,this.pb);
    ellipse(this.fx,this.fy-50,20,50);  //draws big petals
    ellipse(this.fx,this.fy+50,20,50);
    ellipse(this.fx+50,this.fy,50,20);
    ellipse(this.fx-50,this.fy,50,20);
    
    fill(this.pr2,this.pg2,this.pb2);
    ellipse(this.fx+25,this.fy+25,20,20);  //draws small petals
    ellipse(this.fx-25,this.fy+25,20,20);
    ellipse(this.fx-25,this.fy-25,20,20);
    ellipse(this.fx+25,this.fy-25,20,20);
  }
}