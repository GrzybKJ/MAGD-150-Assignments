var poorRichard;
var garamond;
var title;
var spw1;
var spw2;
var pdf;
var tr = 255;
var tg = 255;
var tb = 255;

function preload() {
  poorRichard = loadFont("POORRICH.TTF");
  garamond = loadFont("GARA.TTF");
  title = loadStrings("title.txt");
  spw1 = loadImage("spw1.jpg");
  spw2 = loadImage("spw2.png");
  pdf = createPDF();
  pdf.beginRecord();
}

function setup() {
  createCanvas(400, 500);
  spw1.filter(GRAY);
  spw2.filter(GRAY);
}

function draw() {
  background(50);
  
  image(spw1,50,100);
  spw1.resize(300,150);
  image(spw2,50,270);
  spw2.resize(300,150);
  
  fill(tr,tg,tb);
  textSize(30);
  textFont(poorRichard);
  textAlign(CENTER);
  text(title,200,50);
  
  textSize(15);
  textFont(garamond);
  text("Coming to theaters this summer",200,80);
  text("Rated PG-13",200,450);
}

function mousePressed() {
  pdf.save();
}

function keyPressed() {
  tr = random(255);
  tg = random(255);
  tb = random(255);
  tint(tr,tg,tb);
}