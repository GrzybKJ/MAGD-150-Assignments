var rectx = 50;
var recty = 290;
var rectw = 120;
var recth = 80;

var circx = 250;
var circy = 290;
var circw = 80;
var circh = 80;

var tvr = 0;
var tvg = 255;
var tvb = 0;

var ballr = 0;
var ballg = 0;
var ballb = 255;

var ballx = 100;
var bally = 85;
var ballspeed = 3;

function setup(){
  createCanvas(400,400);
  stroke(0);
  noFill();
}

function draw(){
  background(150);
  fill(80);
  rect(40,260,320,200);
  rect(120,190,150,20);
  rect(40,20,320,160);
  
  fill(tvr,tvg,tvb);
  rect(50,30,300,140);
  
  fill(ballr,ballg,ballb);
  ellipse(ballx,bally,30,30);
  ballx+=ballspeed;
  
  if(ballx-15<=35 || ballx+15>335){
    ballspeed*=-1
  }
  
  fill(200); 
  rect(rectx,recty,rectw,recth);
  textSize(15);
  ellipseMode(CORNER);
  ellipse(circx,circy,circw,circh);
 
  if(mouseIsPressed){
  if(mouseX>rectx && mouseX <rectx+rectw && mouseY>recty && mouseY <recty+recth){ 
    tvr=random(0,255);
    tvg=random(0,255);
    tvb=random(0,255);
  }
  else if(mouseX>circx && mouseX <circw+circy && mouseY>circy && mouseY <circy+circh){
    ballr=random(0,255);
    ballg=random(0,255);
    ballb=random(0,255);
  }
 } 
 fill(0);
 strokeWeight(1);
 text('BACKGROUND',56,330);
 text('BALL',270,330);

}