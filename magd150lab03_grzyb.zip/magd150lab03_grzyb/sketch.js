function setup() {
  createCanvas(400, 400);
}

function draw() {

  var left = '20.00';
  var top = '20.00';
  var mx = constrain(mouseX,(float(left)),(width - 20));
  var my = constrain(mouseY,(float(top)),(height - 20));
  
  var num1 = 8;
  var num2= 2;
  print('The sum of ' + num1 + ' and ' + num2 + ' is ' + (num1+num2));
  print('The product of ' + num1 + ' and ' + num2 + ' is ' + (num1*num2));
  print(num1 + ' divided by ' + num2 + ' is ' + (num1/num2));
  
  var num3 = 3;
  var num4 = 9;
  var num5 = 7;
  var numarray = [num3,num4,num5];
  print('Of the numbers ' + num3 + ', ' + num4 + ', and ' + num5 + ', ' +     max(numarray) + ' is the highest.');
  print('Of the numbers ' + num3 + ', ' + num4 + ', and ' + num5 + ', ' +     min(numarray) + ' is the lowest.');
  
  background(0,100,200);
  ellipse(mx,my,40,40);
  ellipse((mx+60),(my-100),50,50);
  ellipse((mx+20),(my-200),50,50);
  ellipse((mx-100),(my+30),20,20);
  ellipse((mx-130),(my-150),100,100);
  ellipse((mx-40),(my-70),30,30);
  ellipse((mx+150),(my+30),80,80);
  ellipse((mx-20),(my+100),100,100);
  noStroke();
  fill(255,70);
  
  
}
